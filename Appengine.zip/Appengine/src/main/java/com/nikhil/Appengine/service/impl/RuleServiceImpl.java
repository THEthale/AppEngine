package com.nikhil.Appengine.service.impl;

import com.nikhil.Appengine.dto.RuleDTO;
import com.nikhil.Appengine.dto.RuleRequest;
import com.nikhil.Appengine.model.Node;
import com.nikhil.Appengine.model.Rule;
import com.nikhil.Appengine.repository.RuleRepository;
import com.nikhil.Appengine.service.RuleParser;
import com.nikhil.Appengine.service.RuleService;
import com.nikhil.Appengine.service.ExpressionEvaluator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityNotFoundException;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class RuleServiceImpl implements RuleService {
    private final RuleRepository ruleRepository;
    private final RuleParser ruleParser;
    private final ExpressionEvaluator expressionEvaluator;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RuleDTO createRule(RuleRequest request) {
        log.info("Creating rule with name: {}", request.getName());
        String jsonOutput;
        try {
            jsonOutput = ruleParser.parse(request.getRuleString());
        } catch (Exception e) {
            log.error("Rule parsing failed: {}", e.getMessage());
            throw new IllegalArgumentException("Invalid rule format: " + e.getMessage());
        }

        Rule rule = Rule.builder()
                .name(request.getName())
                .ruleString(request.getRuleString())
                .jsonOutput(jsonOutput) // Assuming a field for JSON output
                .status("ACTIVE")
                .build();

        Rule savedRule = ruleRepository.save(rule);
        log.info("Rule created with ID: {}", savedRule.getId());
        return convertToDTO(savedRule);
    }

    @Override
    public RuleDTO getRule(Long id) {
        Rule rule = ruleRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Rule not found"));
        return convertToDTO(rule);
    }

    @Override
    public List<RuleDTO> getAllRules() {
        return ruleRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RuleDTO updateRule(Long id, RuleRequest request) {
        Rule rule = ruleRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Rule not found"));

        String jsonOutput;
        try {
            jsonOutput = ruleParser.parse(request.getRuleString());
        } catch (Exception e) {
            log.error("Rule parsing failed: {}", e.getMessage());
            throw new IllegalArgumentException("Invalid rule format: " + e.getMessage());
        }

        rule.setName(request.getName());
        rule.setRuleString(request.getRuleString());
        rule.setJsonOutput(jsonOutput); // Update JSON output

        Rule updatedRule = ruleRepository.save(rule);
        log.info("Rule updated with ID: {}", updatedRule.getId());
        return convertToDTO(updatedRule);
    }

    @Override
    public boolean evaluateRule(Long ruleId, Map<String, Object> data) {
        Rule rule = ruleRepository.findById(ruleId)
                .orElseThrow(() -> new EntityNotFoundException("Rule not found"));
        log.info("Evaluating rule with ID: {}", ruleId);
        return expressionEvaluator.evaluate(rule.getRootNode(), data);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public RuleDTO combineRules(List<Long> ruleIds) {
        List<Rule> rules = ruleRepository.findAllById(ruleIds);
        if (rules.size() != ruleIds.size()) {
            throw new EntityNotFoundException("One or more rules not found");
        }

        String combinedRuleString = rules.stream()
                .map(rule -> "(" + rule.getRuleString() + ")")
                .collect(Collectors.joining(" OR "));

        String jsonOutput;
        try {
            jsonOutput = ruleParser.parse(combinedRuleString);
        } catch (Exception e) {
            log.error("Combined rule parsing failed: {}", e.getMessage());
            throw new IllegalArgumentException("Invalid combined rule format: " + e.getMessage());
        }

        Rule combinedRule = Rule.builder()
                .name("Combined Rule " + UUID.randomUUID().toString().substring(0, 8))
                .ruleString(combinedRuleString)
                .jsonOutput(jsonOutput) // Store JSON output for combined rules
                .status("ACTIVE")
                .build();

        Rule savedRule = ruleRepository.save(combinedRule);
        log.info("Combined rule created with ID: {}", savedRule.getId());
        return convertToDTO(savedRule);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deactivateRule(Long id) {
        Rule rule = ruleRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Rule not found"));

        if ("INACTIVE".equals(rule.getStatus())) {
            throw new IllegalStateException("Rule is already inactive");
        }

        rule.setStatus("INACTIVE");
        ruleRepository.save(rule);

        log.info("Rule deactivated with ID: {}", id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void activateRule(Long id) {
        Rule rule = ruleRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Rule not found"));

        if ("ACTIVE".equals(rule.getStatus())) {
            throw new IllegalStateException("Rule is already active");
        }

        rule.setStatus("ACTIVE");
        ruleRepository.save(rule);

        log.info("Rule activated with ID: {}", id);
    }

    @Override
    public List<RuleDTO> getRulesByStatus(String status) {
        return ruleRepository.findByStatusOrderByCreatedAtDesc(status).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public boolean validateRuleString(String ruleString) {
        try {
            ruleParser.parse(ruleString);
            return true;
        } catch (Exception e) {
            log.error("Rule validation failed: {}", e.getMessage());
            return false;
        }
    }

    @Override
    public Map<Long, Boolean> evaluateRules(List<Long> ruleIds, Map<String, Object> data) {
        List<Rule> rules = ruleRepository.findAllById(ruleIds);

        Map<Long, Boolean> results = new HashMap<>();

        for (Rule rule : rules) {
            boolean result = expressionEvaluator.evaluate(rule.getRootNode(), data);
            results.put(rule.getId(), result);
            log.info("Rule ID {} evaluated with result: {}", rule.getId(), result);
        }

        return results;
    }

    private RuleDTO convertToDTO(Rule rule) {
        return RuleDTO.builder()
                .id(rule.getId())
                .name(rule.getName())
                .ruleString(rule.getRuleString())
                .jsonOutput(rule.getJsonOutput()) // Include JSON output in DTO
                .status(rule.getStatus())
                .createdAt(rule.getCreatedAt())
                .updatedAt(rule.getUpdatedAt())
                .build();
    }
}