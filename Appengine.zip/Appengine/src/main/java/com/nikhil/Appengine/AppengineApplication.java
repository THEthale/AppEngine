package com.nikhil.Appengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppengineApplication {
	public static void main(String[] args) {
		SpringApplication.run(AppengineApplication.class, args);
	}
}
