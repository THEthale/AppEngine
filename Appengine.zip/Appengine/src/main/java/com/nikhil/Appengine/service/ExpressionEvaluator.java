package com.nikhil.Appengine.service;

import com.nikhil.Appengine.model.Node;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.logging.Logger;

@Component
public class ExpressionEvaluator {

    private static final Logger logger = Logger.getLogger(ExpressionEvaluator.class.getName());

    public boolean evaluate(Node node, Map<String, Object> data) {
        if (node == null) return false;

        if ("operator".equals(node.getType())) {
            boolean leftResult = evaluate(node.getLeft(), data);
            boolean rightResult = evaluate(node.getRight(), data);

            return switch (node.getValue().toUpperCase()) {
                case "AND" -> leftResult && rightResult;
                case "OR" -> leftResult || rightResult;
                default -> {
                    logger.warning("Unsupported logical operator: " + node.getValue());
                    yield false;
                }
            };
        } else {
            return evaluateCondition(node.getValue(), data);
        }
    }

    private boolean evaluateCondition(String condition, Map<String, Object> data) {
        String[] parts = condition.trim().split("\\s+");
        if (parts.length != 3) {
            logger.warning("Invalid condition format: " + condition);
            return false;
        }

        String field = parts[0];
        String operator = parts[1];
        String value = parts[2].replace("'", "");

        Object fieldValue = data.get(field);
        if (fieldValue == null) {
            logger.warning("Field not found in data: " + field);
            return false;
        }

        return switch (operator) {
            case ">" -> compareValues(fieldValue, value, true);
            case "<" -> compareValues(fieldValue, value, false);
            case "=" -> fieldValue.toString().equals(value);
            default -> {
                logger.warning("Unsupported comparison operator: " + operator);
                yield false;
            }
        };
    }

    private boolean compareValues(Object fieldValue, String value, boolean greaterThan) {
        try {
            double fieldNum = Double.parseDouble(fieldValue.toString());
            double valueNum = Double.parseDouble(value);
            return greaterThan ? fieldNum > valueNum : fieldNum < valueNum;
        } catch (NumberFormatException e) {
            logger.severe("Number format exception: " + e.getMessage());
            return false;
        }
    }
}
