/*
package com.nikhil.Appengine.parser;

import com.nikhil.Appengine.model.Node;
import java.util.Map;

public class ExpressionEvaluator {

    // Evaluates the AST (Node tree) recursively
    public static boolean evaluate(Node node, Map<String, Object> data) {
        if (node.getType().equals("condition")) {
            return evaluateCondition(node.getValue(), data);
        } else if (node.getType().equals("operator")) {
            boolean left = evaluate(node.getLeftNode(), data);
            boolean right = evaluate(node.getRightNode(), data);
            // Handle AND and OR logical operators
            return node.getValue().equals("AND") ? left && right : left || right;
        }
        return false;
    }

    // Evaluates a single condition node (e.g., "age > 30")
    private static boolean evaluateCondition(String condition, Map<String, Object> data) {
        // Split the condition into parts like ["age", ">", "30"]
        String[] parts = condition.split(" ");
        if (parts.length != 3) {
            throw new IllegalArgumentException("Invalid condition format: " + condition);
        }

        String attribute = parts[0];  // Attribute like "age"
        String operator = parts[1];   // Operator like ">", "<", "=="
        String targetValue = parts[2]; // Value to compare, e.g., "30"

        // Get the actual value from the data map
        Object value = data.get(attribute);

        // Check for null values in the data
        if (value == null) {
            throw new IllegalArgumentException("Missing data for attribute: " + attribute);
        }

        // Convert targetValue to the correct type and compare it with the actual value
        switch (operator) {
            case ">":
                return (int) value > Integer.parseInt(targetValue);
            case "<":
                return (int) value < Integer.parseInt(targetValue);
            case "==":
                return value.toString().equals(targetValue);
            case "!=":
                return !value.toString().equals(targetValue);
            case ">=":
                return (int) value >= Integer.parseInt(targetValue);
            case "<=":
                return (int) value <= Integer.parseInt(targetValue);
            default:
                throw new IllegalArgumentException("Unknown operator: " + operator);
        }
    }
}
*/
