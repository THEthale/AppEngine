/*
package com.nikhil.Appengine.parser;

import com.nikhil.Appengine.model.Node;
import org.springframework.stereotype.Component;

import java.util.Stack;

@Component
public class RuleParser {

    public Node parseRule(String ruleString) {
        // Dummy implementation for parsing ruleString into AST (for simplicity)
        Stack<Node> stack = new Stack<>();
        String[] tokens = ruleString.split(" ");

        for (String token : tokens) {
            if (token.equals("AND") || token.equals("OR")) {
                Node rightNode = stack.pop();
                Node leftNode = stack.pop();
                stack.push(new Node("operator", token, leftNode, rightNode));
            } else if (token.equals(">") || token.equals("<") || token.equals("=")) {
                String operator = token;
                String leftOperand = stack.pop().getValue();
                String rightOperand = stack.pop().getValue();
                stack.push(new Node("condition", operator, new Node("value", leftOperand, null, null), new Node("value", rightOperand, null, null)));
            } else {
                stack.push(new Node("value", token, null, null));
            }
        }

        return stack.pop();
    }
}
*/
