package com.nikhil.Appengine.exception;

public class RuleParsingException extends RuntimeException {
    public RuleParsingException(String message) {
        super(message);
    }
}