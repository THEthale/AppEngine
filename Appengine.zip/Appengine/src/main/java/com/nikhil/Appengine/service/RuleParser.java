package com.nikhil.Appengine.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nikhil.Appengine.exception.RuleParsingException;
import com.nikhil.Appengine.model.Node;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class RuleParser {

    private static final Pattern CONDITION_PATTERN =
            Pattern.compile("([a-zA-Z_][a-zA-Z0-9_]*)\\s*([<>=])\\s*('[^']*'|\\d+(\\.\\d+)?)");

    private final ObjectMapper objectMapper = new ObjectMapper();

    public String parse(String ruleString) throws RuleParsingException {
        if (ruleString == null || ruleString.trim().isEmpty()) {
            throw new RuleParsingException("Rule string cannot be empty.");
        }

        List<String> tokens = tokenize(ruleString);
        Node rootNode = buildTree(tokens);
        return convertToJson(rootNode);
    }

    private List<String> tokenize(String ruleString) {
        List<String> tokens = new ArrayList<>();
        StringBuilder currentToken = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < ruleString.length(); i++) {
            char c = ruleString.charAt(i);

            if (c == '\'') {
                inQuotes = !inQuotes;
                currentToken.append(c);
            } else if (inQuotes) {
                currentToken.append(c);
            } else if (c == '(' || c == ')') {
                if (currentToken.length() > 0) {
                    tokens.add(currentToken.toString().trim());
                    currentToken = new StringBuilder();
                }
                tokens.add(String.valueOf(c));
            } else if (Character.isWhitespace(c)) {
                if (currentToken.length() > 0) {
                    tokens.add(currentToken.toString().trim());
                    currentToken = new StringBuilder();
                }
            } else {
                currentToken.append(c);
            }
        }

        if (currentToken.length() > 0) {
            tokens.add(currentToken.toString().trim());
        }

        return tokens;
    }

    private Node buildTree(List<String> tokens) throws RuleParsingException {
        Stack<Node> nodeStack = new Stack<>();
        Stack<String> operatorStack = new Stack<>();

        for (int i = 0; i < tokens.size(); i++) {
            String token = tokens.get(i);

            if (token.equals("(")) {
                operatorStack.push(token);
            }
            else if (token.equals(")")) {
                while (!operatorStack.isEmpty() && !operatorStack.peek().equals("(")) {
                    processOperator(nodeStack, operatorStack.pop());
                }
                if (!operatorStack.isEmpty()) {
                    operatorStack.pop(); // Remove "("
                }
            }
            else if (isOperator(token)) {
                while (!operatorStack.isEmpty() && precedence(operatorStack.peek()) >= precedence(token)) {
                    processOperator(nodeStack, operatorStack.pop());
                }
                operatorStack.push(token);
            }
            else if (isCondition(token)) {
                nodeStack.push(new Node(token, "condition"));
            }
            else {
                throw new RuleParsingException("Invalid token: " + token);
            }
        }

        while (!operatorStack.isEmpty()) {
            processOperator(nodeStack, operatorStack.pop());
        }

        if (nodeStack.isEmpty()) {
            throw new RuleParsingException("Invalid expression");
        }

        return nodeStack.pop();
    }

    private void processOperator(Stack<Node> nodeStack, String operator) throws RuleParsingException {
        if (nodeStack.size() < 2) {
            throw new RuleParsingException("Invalid expression: not enough operands");
        }

        Node right = nodeStack.pop();
        Node left = nodeStack.pop();

        Node operatorNode = new Node(operator.toUpperCase(), "operator");
        operatorNode.setLeft(left);
        operatorNode.setRight(right);

        nodeStack.push(operatorNode);
    }

    private boolean isOperator(String token) {
        return token.equalsIgnoreCase("AND") || token.equalsIgnoreCase("OR");
    }

    private boolean isCondition(String token) {
        Matcher matcher = CONDITION_PATTERN.matcher(token);
        return matcher.matches();
    }

    private int precedence(String operator) {
        if (operator.equals("(")) return 0;
        return switch (operator.toUpperCase()) {
            case "AND" -> 2;
            case "OR" -> 1;
            default -> -1;
        };
    }

    private String convertToJson(Node rootNode) throws RuleParsingException {
        try {
            return objectMapper.writeValueAsString(rootNode);
        } catch (JsonProcessingException e) {
            throw new RuleParsingException("Error converting to JSON: " + e.getMessage());
        }
    }
}