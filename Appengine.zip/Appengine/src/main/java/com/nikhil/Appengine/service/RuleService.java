package com.nikhil.Appengine.service;

import com.nikhil.Appengine.dto.RuleDTO;
import com.nikhil.Appengine.dto.RuleRequest;
import com.nikhil.Appengine.exception.InvalidRuleException;

import java.util.List;
import java.util.Map;
import java.util.Optional;
public interface RuleService {
    RuleDTO createRule(RuleRequest request);
    RuleDTO getRule(Long id);
    List<RuleDTO> getAllRules();
    RuleDTO updateRule(Long id, RuleRequest request);
    boolean evaluateRule(Long ruleId, Map<String, Object> data);
    RuleDTO combineRules(List<Long> ruleIds);
    void deactivateRule(Long id);
    void activateRule(Long id);
    List<RuleDTO> getRulesByStatus(String status);
    boolean validateRuleString(String ruleString);
    Map<Long, Boolean> evaluateRules(List<Long> ruleIds, Map<String, Object> data);
}
