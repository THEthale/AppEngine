package com.nikhil.Appengine.model;

public class AST {
    private Node root;

    public AST(Node root) {
        this.root = root;
    }

    public Node getRoot() {
        return root;
    }

    public void setRoot(Node root) {
        this.root = root;
    }
}
