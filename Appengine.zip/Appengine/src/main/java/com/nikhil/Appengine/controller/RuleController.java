package com.nikhil.Appengine.controller;

import com.nikhil.Appengine.dto.RuleDTO;
import com.nikhil.Appengine.dto.RuleRequest;
import com.nikhil.Appengine.model.Node;
import com.nikhil.Appengine.service.RuleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
@RestController
@RequestMapping("/api/rules")
@RequiredArgsConstructor
public class RuleController {
    private final RuleService ruleService;

    @PostMapping
    public ResponseEntity<RuleDTO> createRule(@Valid @RequestBody RuleRequest request) {
        return ResponseEntity.ok(ruleService.createRule(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<RuleDTO> getRule(@PathVariable Long id) {
        return ResponseEntity.ok(ruleService.getRule(id));
    }

    @GetMapping
    public ResponseEntity<List<RuleDTO>> getAllRules() {
        return ResponseEntity.ok(ruleService.getAllRules());
    }

    @PutMapping("/{id}")
    public ResponseEntity<RuleDTO> updateRule(
            @PathVariable Long id,
            @Valid @RequestBody RuleRequest request) {
        return ResponseEntity.ok(ruleService.updateRule(id, request));
    }

    @PostMapping("/{ruleId}/evaluate")
    public ResponseEntity<Boolean> evaluateRule(
            @PathVariable Long ruleId,
            @RequestBody Map<String, Object> data) {
        return ResponseEntity.ok(ruleService.evaluateRule(ruleId, data));
    }

    @PostMapping("/combine")
    public ResponseEntity<RuleDTO> combineRules(@RequestBody List<Long> ruleIds) {
        return ResponseEntity.ok(ruleService.combineRules(ruleIds));
    }

    @PostMapping("/{id}/deactivate")
    public ResponseEntity<Void> deactivateRule(@PathVariable Long id) {
        ruleService.deactivateRule(id);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/{id}/activate")
    public ResponseEntity<Void> activateRule(@PathVariable Long id) {
        ruleService.activateRule(id);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<RuleDTO>> getRulesByStatus(@PathVariable String status) {
        return ResponseEntity.ok(ruleService.getRulesByStatus(status));
    }

    @PostMapping("/validate")
    public ResponseEntity<Boolean> validateRule(@RequestBody String ruleString) {
        return ResponseEntity.ok(ruleService.validateRuleString(ruleString));
    }

    @PostMapping("/evaluate-batch")
    public ResponseEntity<Map<Long, Boolean>> evaluateRules(
            @RequestBody List<Long> ruleIds,
            @RequestBody Map<String, Object> data) {
        return ResponseEntity.ok(ruleService.evaluateRules(ruleIds, data));
    }
}