/*
package com.nikhil.Appengine.config;

import com.nikhil.Appengine.parser.RuleParser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@EnableWebMvc
public class AppConfig {
    @Bean
    public RuleParser ruleParser() {
        return new RuleParser();
    }
}
*/
