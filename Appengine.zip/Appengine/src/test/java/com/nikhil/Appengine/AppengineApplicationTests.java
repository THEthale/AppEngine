package com.nikhil.Appengine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppengineApplicationTests {

	@Test
	void contextLoads() {
	}

}
